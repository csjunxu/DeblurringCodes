%
%   x = vec_shrinkage( y , lambda )
%
% vectorized soft-thresholding of vector "y", with threshold lambda.
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@.gmail.com
%
 
function x_min = vec_shrinkage( y , lambda )
 
[n N] = size( y );
y = reshape(y, n,[] );
 
norm_y = sqrt( sum(y.^2) );
 
c = soft( norm_y, lambda );
x_min = repmat(c./norm_y, n,1).*y;
 
 


