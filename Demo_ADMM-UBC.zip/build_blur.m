% function filter = build_blur( BlurDim , n_filter)
%
% Outputs: filter - one out of seven possible blurring filters. 
% Inputs:  BlurDim - dimension of the blurring filter ( BlurDim x BlurDim  pixels ). 
%          n_filter - filter type, from 1 to 4: 
%                       1 -  uniform
%                       2 -  out-of-focus
%                       3 -  linear motion at 135�
%                       4 -  Gaussian
%
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
 
 
function filter = build_blur( BlurDim , n_filter)
 
switch n_filter  % 4 possible filters:
    
    case 1,   % uniform
        filter = ones(BlurDim,BlurDim);
        
    case 2,   % out_of_focus
        [filter] = fspecial('disk',BlurDim/2);
        
    case 3,   % linear motion
        length = BlurDim;  ang = 135;
        [filter] =  motion_filter( length, ang);
        
    case 4,   % Gaussian (sig = 2)
        sig = (BlurDim-1)/4; % (sig = 2)
        filter  = Gauss_filter(BlurDim,sig);  
        
    otherwise,
        fprintf('ERROR: n_filter should be 1, 2, 3 or 4.')
        
end;
filter = filter/sum(sum(filter));
 
 
 


