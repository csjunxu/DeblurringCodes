%
% function y = soft(x,T)
%
% Softh-thresholding funciton of "x", with theshold "T".
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@.gmail.com
%

function y = soft(x,T)
if sum(abs(T(:)))==0
   y = x;
else
   y = max(abs(x) - T, 0);
   y = y./(y+T) .* x;
end


