% 
% function [x x_full time_x cost ISNR mse_full] = Deblurring_ADMM_UBC(y,h,filter_size,lambda,opt)
% 
% Function that implements the deblurring methods of [1,2] ("FA-MS", "TV-MS", "FA-CG" and "TV-CG"), 
% using the alternating direction method of multipliers (ADMM) and assuming Unknown Boundary Conditions (UBC).
%
%  [1]  Mariana S. C. Almeida and M�rio A. T. Figueiredo; "Deconvolving images with unknown boundaries using the alternating 
%       direction method of multipliers", IEEE Transactions on Image Processing, vol. 22, No. 8, pp. 3074-3086, 2013. 
%      (available at http://arxiv.org/abs/1210.2687)
%
%  [2]  Mariana S. C. Almeida and M�rio A. T. Figueiredo; "Frame-based image deblurring
%       with unknown boundary conditions using the Alternating Direction Method of Multipliers", 
%       IEEE Int. Conf. on Image Processing - ICIP, Melbourne, Australia, September, 2013.
%
%
% Deblurring_ADMM_UBC solves the "Frame-Analysis" and "Total-Variation" deblurring problems with UBC (using the ADMM):
%
%  "Frame-Analysis":    argmin || y - M*H*x ||^2  + lambda * Phi( WT(x) )
%                          x
%
%  "Total-Variation"    argmin || y - M*H*x ||^2  + lambda * TV(x)
%                          x
% 
% where and H represents the blurring operation, and M is a mask that only observes the pixels 
% that does not depend on the boundaries of "x" that are exterior to "y".
%
%
% Outputs:  x       = Central pixels of the estimated image (excluding boundaries); "x" has size of "y".
%           x_full  = Full estimated image, including estimated boundaries; "x" is larger than "y". 
%           time_x  = Processing time along iterations, and excluding reports (prints and plots). time_x(1) has the initializations' time.
%           cost    = Cost function along iterations. cost(1) has the initial value of the cost function.
%           ISNR    = ISNR computed for the observed pixels.
%           mse_full= MSE computed for the full estimate image (including boundaries). If the sharp image "opt.x0" has the size of "y",
%                     "mse_full" is only computed for the interior pixels of "x" (excluding boundaries).
%
% Inputs:   y           =  Observed blurred image.
%           h           =  Blurring filter (may have the size of "y").
%           filter_size =  Vector [size_x size_y] with the support of the blurring filter.
%                          size_x and size_x should be odd, and are used to determine the size of "x" (including boundaries). 
%           opt =  method's OPTIONS:
%               opt.x0          =  Original sharp image, used to compute "ISNR" and "mse_full".
%                                   Default=[].       
%               opt.approach    =  Approach used for deblurrring with UBC:
%                                   1) 'MD' - Mask decoupling approach.  (default)
%                                   2) 'CG' - Using the  conjugate gradient (you may pass the number of CG iterations)
%                                   Default='MD'.
%               opt.reg         =  Type of regularization:  
%                                   1) 'Total-Variation' (default)
%                                   2) 'Frame-Analysis': You may pass "W" and "WT", "Phi" and "ProxPhi" functions (see ahead).
%                                   Default='Total-Variation'.
%               opt.WT          = Analyses frame operator. (just for "Frame-Analysis" regularization)
%                                 Default = Identity function: (@(x) x).
%               opt.W           = Synthesis frame operator. (just for "Frame-Analysis" regularization)
%                                 Default = Identity function: (@(x) x).
%               opt.Phi         = "Phi" function. (just for "Frame-Analysis" regularization)
%                                 Default = L1-norm: @(w)sum(abs(w)).
%               opt.ProxPhi     =  Proximity operator of "Phi". (just for "Frame-Analysis" regularization)
%                                  Default = Soft-thresholding: @(w,tau) soft(w,tau).
%               opt.StopCriterion = Stopping criterion: 
%                                   1) Relative variation of the cost function below "Tol" option.
%                                   2) Relative variation of the image x below "Tol" option.
%                                   3) Value of the cost function below "Tol" option.
%                                 Default = 2.
%               opt.Tol         = Stopping tolerance.
%                                 Default = 10^-4.
%
%               opt.Mask_y      = Binary mask, with the size of "y", that may mask some of the pixels observed in "y".
%                                 Default = ones(size(y)).    
%               opt.max_iter    = Maximum number of iterations of the ADMM.
%                                 Default = 500;
%               
%               opt.ctr_print   = Control parameter to report (print) results:  
%                                   ctr_print = 1 - prints.
%                                   ctr_print = 0 - does not print.
%                                 Default = 1.
%               opt.ctr_print   = Control parameter to show (plot) results:  
%                                   ctr_print = 1 - plots.
%                                   ctr_print = 0 - does not plot.
%                                 Default = 1.
%
%                 opt.miu_hx    =  "miu_hx" parameter of the ADMM  
%                                  Default = min(1,5000*lambda).
%                 opt.miu_wx    =  "miu_wx" parameter of the ADMM  (just for "Frame-Analysis" regularization)
%                                  Default = 10*lambda.
%                 opt.miu_hx    =  "miu_hx" parameter of the ADMM  (just for "Total-Variation" regularization)
%                                  Default = 10*lambda.
%
%
%
% Mariana S. C. Almeida; 2013 
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@.gmail.com
% 
%
 
 
function [x_in x_full time_x cost ISNR mse_full] = Deblurring_ADMM_UBC(y,h,filter_size,lambda,opt)
 
tic_pre = tic;
 
% % % % INITIALIZATION and VALIDATION:
% INPUTS (default values):
try opt.x0;             x0 = opt.x0;                        catch x0 = []; end
try opt.reg;            str_reg = opt.reg;                  catch str_reg = 'Total-Variation'; end
try opt.approach;       str_approach = opt.approach;        catch str_approach = 'MD';   end
try opt.StopCriterion;  StopCriterion = opt.StopCriterion;  catch StopCriterion = 2; end
try opt.Tol;            Tol = opt.Tol;                      catch Tol = 10^-4; end
try opt.Mask_y;         Mask_y = opt.Mask_y;                catch Mask_y =  ones(size(y)); end
try opt.max_iter;       max_iter = opt.max_iter;            catch max_iter = 500; end
try opt.n_CG;           n_CG = opt.n_CG;                    catch n_CG = 1; end
 
try opt.W;              W = opt.W;                          catch W = @(x) x; end
try opt.WT;             WT = opt.WT;                        catch WT = @(x) x; end
try opt.Phi;            Phi = opt.Phi;                      catch Phi = @(w) sum(abs(w)); end
try opt.ProxPhi;        ProxPhi = opt.ProxPhi;              catch ProxPhi = @(w,tau) soft(w,tau); end
 
try opt.ctr_print;      ctr_print = opt.ctr_print;          catch ctr_print = 1; end
try opt.ctr_plot;       ctr_plot = opt.ctr_plot;            catch ctr_plot = 1; end
 
try opt.miu_hx;       miu_hx = opt.miu_hx;                  catch miu_hx =  min(1,5000*lambda); end
try opt.miu_wx;       miu_wx = opt.miu_wx;                  catch miu_wx = 10*lambda; end
try opt.miu_tv_x;     miu_tv_x = opt.miu_tv_x;              catch miu_tv_x = 10*lambda; end
 
% Computing initializations - 1:
l_size = round((filter_size-1)/2);
lx = l_size(1); ly = l_size(2);
try opt.x_init          
    x_init = opt.x_init;
    % validation
    if ~( size(x_init) == size(y) + [2*lx 2*ly] )
        fprintf('ERROR (Deblurring_ADMM_UBC): "opt.x_init" should be %dx%d pixels of size.', size(y) + [2*lx 2*ly] ),
    end
catch
    x_in = y;
    x_in = fill_image(x_in,Mask_y);
    x_init = padarray( padarray( x_in, lx , 'replicate' )' ,ly , 'replicate')' ;
    x = x_init;
end
% INPUTS (end)
 
 
% Computing initializations - 2:
l_size = round((filter_size-1)/2);
lx = l_size(1); ly = l_size(2);
 
[sz1 sz2] = size(x);
h = ht2h( h2ht(h,lx,ly) , sz1,sz2 );
MMT = Mask_y;
MTM = padarray( padarray(Mask_y, lx , 0 )' , ly , 0)';
M = @(x) x(1+lx:end-lx,1+ly:end-ly).*Mask_y;
MT = @(x) padarray( padarray( x.*Mask_y, lx , 0 )' , ly , 0 )';
MTy = MT(y);
 
sz_up=ceil(log(size(x))/log(2));
delta1 = 2^sz_up(1)-sz1;   
delta2 = 2^sz_up(2)-sz2;   
% Computing initializations - 2 (end)
 
% Inputs (validation and initializations):
if delta1~=0 | delta2~=0
    fprintf('\n WARNING (Deblurring_ADMM_UBC): The size of the image estimate (%dx%d) is not a power of 2.',sz1,sz2),
    fprintf('\n                                Function W and WT may not be prepared for that.'),
end
 
if      strcmp(str_approach,'MD'),   ctr_CG = 0; %ctr_MD = 1;
elseif  strcmp(str_approach,'CG'),   ctr_CG = 1; %ctr_MD = 0;
else   fprintf('\nERROR (Deblurring_ADMM_UBC): "opt.approach" must be either "MD" or "CG".'), return, end
 
if strcmp(str_reg,'Total-Variation'),
    ctr_FA = 0; 
    % TV filters:
    filter_tv(:,:,1) = ht2h([0 0.5 -0.5], sz1 ,sz2);
    filter_tv(:,:,2) = ht2h([0; 0.5 ; -0.5], sz1 ,sz2);
    n_tv = size(filter_tv,3);
    sum_tvTtv_f = zeros(sz1,sz2);
    for i = 1:n_tv
        tv_f(:,:,i) = fft2(filter_tv(:,:,i));
        tvT_f(:,:,i) = conj(tv_f(:,:,i));
        sum_tvTtv_f = sum_tvTtv_f + (tvT_f(:,:,i).*tv_f(:,:,i));
    end
elseif  strcmp(str_reg,'Frame-Analysis'),
    ctr_FA = 1; 
else
    fprintf('\nERROR (Deblurring_ADMM_UBC): "opt.reg" must be either "Total-Variation" or "Frame-Analysis".'),
    return
end
 
if numel(x0),
    if size(x0,1)==sz1 & size(x0,2)==sz2,
        x0_in = M(x0);
        ctr_outMSE =1;
    elseif size(x0)==size(y)
        fprintf('\WARNING (Deblurring_ADMM_UBC): dimensions of "opt.x0" (%dx%d) are iqual to those of "y" (%dx%d)',size(x0),size(y));
        fprintf('\n                              "mse_full" will be only computed on the interior (%dx%d) pixels of "x".');
        ctr_outMSE = 0;
    else
        fprintf('\nERROR (Deblurring_ADMM_UBC): dimensions of "opt.x0" (%dx%d) are different from those of "x" (%dx%d)',size(x0),sz1 ,sz2);
        fprintf('\n                             and from those of the expected image "y" (%dx%d).', size(y));        
        fprintf('\n                             "mse_full" and "ISNR" cannot be computed.');
        return
    end
end
% % % % % INITIALIZATION and VALIDATION (end)
 
 
% % % % % ADMM INITIALIZATIONS:
y_f = fft2(y);
h_f = fft2(h);
h_f_conj = conj(h_f);
hTh_f = h_f_conj.*h_f;
x_f = fft2(x);
hx_f = x_f.*h_f;
hx = ifft2(hx_f);
 
if ctr_CG,  g_hx = M(hx);      else,   g_hx = hx;  end
if ctr_FA,  
    wx = WT(x);     
    g_wx = wx;
else,      
    for i = 1:n_tv,   
        TVx(:,:,i) = ifft2( (tv_f(:,:,i)).* x_f ); 
    end; 
    g_tv_x = TVx;
end
d_hx = 0*g_hx;
if ctr_FA, d_wx = 0*g_wx;               else,   d_tv_x = 0*g_tv_x;  end 
% % % % % ADMM INITIALIZATIONS (end)
 
 
% %  INITIAL STAGE:
% cost0, time0, isnr0, mse0:
if ctr_FA   cost0 = 1/2*sum(sum( (y-M(hx)).^2 )) + lambda*Phi(wx);
else,       cost0 = 1/2*sum(sum( (y-M(hx)).^2 )) + lambda*sum(sum(sum( abs(TVx) ))); end
time_pre = toc(tic_pre);
cost(1) = cost0;
time_x(1) = time_pre;
% ISNR , mse_full:
if numel(x0)
    x_in = M(x); 
    ISNR(1) = 20*log10( norm( Mask_y.*(y-x0_in),'fro')/norm( Mask_y.*(x_in-x0_in),'fro') );
    if ctr_outMSE
        mse_full(1) = norm( (x-x0),'fro')/ numel(x0);
    else
        mse_full(1) = norm( (x_in-x0_in),'fro')/ numel(x0_in);
    end
end
% Report:
if ctr_print
    fprintf('\nADMM-UBC, it=0: cost=%f, ISNR=%f, MSEfull=%f', cost(end), ISNR(end), mse_full(end))
end
if ctr_plot
    fig = figure();
    figure(fig);
    subplot(2,2,1), imagesc(y), colormap gray, axis image, title('Degraded image')
    subplot(2,2,2), plot(cost), colormap gray, axis image, title('Cost funciton')
    subplot(2,2,3), imagesc(x), colormap gray, axis image, title('Image estimate')
    if numel(x0)
        subplot(2,2,4), imagesc(x0), colormap gray, axis image, title('Original image')
    end
end
% %  INITIAL STAGE (end)
 
 
% % ADMM LOOP:
for k=1:max_iter
    
    tic_iter = tic;
    
    x_old = x;
    g_hx_old = g_hx;
    if ctr_FA,  g_wx_old = g_wx;  else g_tv_x_old = g_tv_x; end
 
    % X-step:
    if ctr_CG 
        
        if ~exist('y_missing'),  y_missing = (1-MTM).*x_init; end
        if ~exist('gd_missing'), gd_missing = y_missing; end
        
        if ctr_FA %FA-CG
            gd_missing = missing_y_frames( gd_missing, MT( g_hx+d_hx ) , g_wx+d_wx , miu_hx, miu_wx , h_f_conj , W , MTM, n_CG);
            gd_hx_all = MT(g_hx + d_hx ) + (1-MTM).*gd_missing;
            
            auxi_hx_all_f = h_f_conj.*( fft2(gd_hx_all) );
            auxi_wx = W( g_wx+d_wx );
            
            x_f = ( miu_hx.*auxi_hx_all_f  + miu_wx.*fft2(auxi_wx) ) ./ ( miu_hx.*hTh_f + miu_wx );
            x =  ifft2( x_f );
        
        else  % TV-CG
            gd_missing = missing_y( gd_missing, MT( g_hx+d_hx ) , g_tv_x+d_tv_x , miu_hx, miu_tv_x , h_f_conj , tvT_f , MTM, n_CG);
            gd_hx_all = MT(g_hx + d_hx ) + (1-MTM).*gd_missing;
            if miu_tv_x
                auxi_tv_x_f = zeros(size(x));
                for i = 1:n_tv
                    auxi_tv_x_f = auxi_tv_x_f + ( (tvT_f(:,:,i)).*fft2( ( g_tv_x(:,:,i)  + d_tv_x(:,:,i) )) ) ;
                end
            end
            x_anterior = x;
            auxi_hx_all_f = h_f_conj.*( fft2(gd_hx_all) );
            x_f = ( miu_hx.*auxi_hx_all_f  +  miu_tv_x*auxi_tv_x_f ) ./ ( miu_hx.*hTh_f + miu_tv_x*sum_tvTtv_f );
            x =  ifft2( x_f );
        end
    else
        if ctr_FA % FA-MD
            auxi_hx_f = h_f_conj.*( fft2(g_hx + d_hx) );
            auxi_wx = W( g_wx+d_wx );
            x_f = ( miu_hx.*auxi_hx_f  + miu_wx.*fft2(auxi_wx)  ) ./ (miu_hx.*hTh_f + miu_wx);
            x =  ifft2( x_f ) ;
        else % TV-MD
            auxi_tv_x_f = zeros(size(x));
            for i = 1:n_tv
                auxi_tv_x_f = auxi_tv_x_f + ( (tvT_f(:,:,i)).*fft2( ( g_tv_x(:,:,i)  + d_tv_x(:,:,i) )) ) ;
            end
            auxi_hx_f = h_f_conj.*( fft2(g_hx + d_hx) );
            x_f = ( miu_hx.*auxi_hx_f + miu_tv_x*auxi_tv_x_f )./( miu_hx.*hTh_f + miu_tv_x*sum_tvTtv_f );
            x = ifft2( x_f );
        end
    end
    % x-setp (end)
    
    
    % u-setps:
    hx = ifft2(h_f.*x_f);
    if ctr_CG,       g_hx = ( y + miu_hx.*(M(hx )-d_hx) ) ./ (miu_hx + 1);
    else,            g_hx = (MT(y) + miu_hx*(hx - d_hx)) ./ (miu_hx + MTM);    end
    
    if ctr_FA
        wx = WT( x );
        g_wx = ProxPhi(wx-d_wx , lambda./miu_wx);
    else
        for i = 1:n_tv
            TVx(:,:,i) = ifft2( (tv_f(:,:,i)).*x_f ) ;
            auxi_tv_x(i,:,:) = (TVx(:,:,i))  -  (d_tv_x(:,:,i));
        end
        g_tv_x = reshape( vec_shrinkage( auxi_tv_x , lambda./miu_tv_x ) , n_tv ,sz1,sz2);
        g_tv_x = permute( g_tv_x , [2 3 1]);
    end
    % u-setps (end)
    
    % d-steps:
    if ctr_CG,          r_hx = M(hx ) - g_hx;
    else,               r_hx = hx - g_hx;               end
    d_hx = d_hx - r_hx;
    
    if ctr_FA,      r_wx = wx - g_wx;       d_wx = d_wx - r_wx;
    else,           r_tv_x = TVx - g_tv_x;  d_tv_x = d_tv_x - r_tv_x; end
    % d-steps (end)
    
    time_x(k+1) = time_x(k) + toc(tic_iter);
 
    
    % ACUTAL STAGE:
    % Cost function:
    if ctr_FA   cost(k+1) = 1/2*sum(sum( (y-M(hx )).^2 )) + lambda*sum(sum(sum( abs(wx) )));
    else,       cost(k+1) = 1/2*sum(sum( (y-M(hx )).^2 )) + lambda*sum(sum(sum( abs(TVx) ))); end
    % ISNR , mse_full:
    if numel(x0)
        x_in = M(x);
        ISNR(k+1) = 20*log10( norm( Mask_y.*(y-x0_in),'fro')/norm( Mask_y.*(x_in-x0_in),'fro') );
        if ctr_outMSE
            mse_full(k+1) = norm( (x-x0),'fro')/ numel(x0);
        else
            mse_full(k+1) = norm( (x_in-x0_in),'fro')/ numel(x0_in);
        end
    end
    % Report:
    if ctr_print
        fprintf('\n  it=%d, cost=%f, ISNR=%f, MSEfull=%f', k, cost(end), ISNR(end), mse_full(end))
        if StopCriterion==1, 
            relative_cost = abs( (cost(end)-cost(end-1)) / cost(end-1) );
            fprintf('   relative-cost=%f', relative_cost)
        elseif StopCriterion==2
            relative_x = norm( x-x_old , 'fro' ) / norm( x_old , 'fro' );
            fprintf('   relative-x=%f', relative_x)
        elseif StopCriterion==3
            fprintf('   (cost targert=%f)', Tol)
        end
    end
    if ctr_plot
        figure(fig);
        subplot(2,2,1), imagesc(y), colormap gray, axis image, title('Degraded image')
        subplot(2,2,2), plot(cost), title('Cost funciton')
        subplot(2,2,3), imagesc(x), colormap gray, axis image, title('Image estimate')
        if numel(x0)
            subplot(2,2,4), imagesc(x0), colormap gray, axis image, title('Original image')
        end
    end
    % ACUTAL STAGE (end)
    
 
    % STOPPING criterion:
    switch StopCriterion
        case 1, % Relative variation of the cost function
            % relative_cost = abs( cost(end)-cost(end-1) / cost(end-1) );
            if relative_cost < Tol & k > 2,
                x_in = M(x);   x_full = x;   fprintf('\n'), return,
            end
        case 2, % Relative variation of x
            % relative_x = norm( x-x_old , 'fro' ) / norm( x_old , 'fro' );
            if relative_x < Tol  & k > 2,
                x_in = M(x);   x_full = x;   fprintf('\n'), return,
            end
        case 3, % Cost function
            if cost < Tol,
                x_in = M(x);   x_full = x;   fprintf('\n'), return,
            end
    end
    % STOPPING criterion (end)
end
 
x_in = M(x);   x_full = x;  fprintf('\n'),
 
end
 


