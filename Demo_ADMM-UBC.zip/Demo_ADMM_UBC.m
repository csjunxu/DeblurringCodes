%
% Demos_ADMM_UBC:
% 
% Demo for the methods of [1,2] ("FA-MS", "TV-MS", "FA-CG" and "TV-CG"),
% for deblurring with UBC ussing ADMM:
%
%  [1]  Mariana S. C. Almeida and M�rio A. T. Figueiredo; "Deconvolving images with unknown boundaries using the alternating 
%       direction method of multipliers", IEEE Transactions on Image Processing, vol. 22, No. 8, pp. 3074-3086, 2013. 
%      (available at http://arxiv.org/abs/1210.2687)
%
%  [2]  Mariana S. C. Almeida and M�rio A. T. Figueiredo; "Frame-based image deblurring
%       with unknown boundary conditions using the Alternating Direction Method of Multipliers", 
%       IEEE Int. Conf. on Image Processing - ICIP, Melbourne, Australia, September, 2013.
%
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
%

clear all,
close all
 
addpath ./images
addpath ./rwt-master/rwt
addpath ./rwt-master/src
 
% LOAD image:
x0 = double(imread('cameraman.tif')); % load 'cameraman.tif'
                                      % Other images: 'lena256.bmp' , 'Satalite.tif'
                                      %               'testpat1.png', 'barbara256.bmp'
x0 = x0-min(x0(:));
x0 = x0/max(x0(:));   % x0 in the range [0,1]
 
BlurDim = 19 ;  % filter size (squared): 9x9 pixels
BSNR = 50;      % BSNR level (in dB)
n_filter = 1;   % filter type: 1 -  uniform
                %              2 -  out-of-focus
                %              3 -  linear motion at 135�
                %              4 -  Gaussian
 
% Blurring filter:
ht = build_blur( BlurDim , n_filter );         % constructs the blurring filter (9x9)
h_full = ht2h( ht , size(x0,1) , size(x0,2));  % filter -> h (256x256 pixels)
 
% Blurring degradation (with realistic BC):
fsize = round( (BlurDim-1)/2 );                      % fsize - size of each side of the filter
y_full = ifft2( fft2(h_full).*fft2(x0) );            % cyclic convolution
y = y_full( 1+fsize:end-fsize , 1+fsize:end-fsize ); % extracting extra pixels with invalid BC
h  = ht2h( ht , size(y,1) , size(y,2));              % filter -> h (238x238 pixels)
 
% Additive noise:
Py = var(y(:));
sigma = sqrt(Py/10^(BSNR/10));
randn('seed',1);  % rand('seed',1);
noise = sigma*randn(size(y));
y = y + noise;
 
 
% Method OPTIONS:
opt.x0 = x0;                % original image (for computing ISNR amd MSE)
opt.reg = 'Frame-Analysis'; % Type of regularization:  
                            %   1) 'Total-Variation' (default)
                            %   2) 'Frame-Analysis': You may pass W and WT, Phi and ProxPhi funcitons.
                                 
% opt.reg = 'Total-Variation';
wav = daubcqf(2);  % 
Wlevel = 4;        % decomposition level
opt.W =  @(x) mirdwt_TI2D(x, wav, Wlevel);  % frame type (in ./rwt-master)
opt.WT = @(x) mrdwt_TI2D(x, wav, Wlevel);   % frame type (in ./rwt-master)
 
filter_size = [BlurDim BlurDim]; % dimensions should be odd
l_size = round((filter_size-1)/2);
lx = l_size(1); ly = l_size(2);
x_out =  padarray( padarray( y, lx , 'replicate' )' , ly , 'replicate')' ;
Wmask = 0*mrdwt_TI2D(x_out, wav, Wlevel); 
Wmask(:,1+size(x_out,2):end) = 1;
 
opt.Phi = @(w) sum(sum(sum( abs( Wmask.*w ) )));     % L1-norm (default)
opt.ProxPhi = @(w,tau) [ w(:,1:size(x_out,2))  soft(w(:,1+size(x_out,2):end),tau) ];  % Soft-thresholding
 
opt.approach = 'MD';     % approach used for deblurrring with UBC:
                         %     1) 'MD' - Mask decoupling approach.  (default)
                         %     2) 'CG' - Using the conjugate gradient: 
                         %               you may pass the number of CG iterations (opt.n_CG = 1 by default)
opt.StopCriterion = 2;   % Stopping criterion: 1 - relative variation of the cost function
                         %                     2 - relative variation of the image x      
                         %                     3 - value of the cost funciton
opt.Tol = 10^-4;         % Stopping tolerance 
opt.Mask_y = ones(size(y)); % May mask some of the pixels in y.
opt.max_iter = 100;         % maximum number of iterations
 
lambda = 0.000002; 
filter_size = [BlurDim BlurDim]; % dimensions of filter_size should be odd
 
[x x_full time_x cost ISNR mse_full] = Deblurring_ADMM_UBC(y,h,filter_size,lambda,opt);
 
 
                         
                         
 


