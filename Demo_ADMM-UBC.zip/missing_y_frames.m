%
%  w = missing_y_frames( x_init, y , u , l1, l2 , hT_f, W,  M, N)
%
%  Function that supports our "FA-CG" approach of [1].
% 
%  [1]  Mariana S. C. Almeida and M�rio A. T. Figueiredo; "Deconvolving images with unknown boundaries using the alternating 
%       direction method of multipliers", IEEE Transactions on Image Processing, vol. 22, No. 8, pp. 3074-3086, 2013. 
%      (available at http://arxiv.org/abs/1210.2687)
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@.gmail.com
% 
%

function  w = missing_y_frames( x_init, y , u , l1, l2 , hT_f, W,  M, N)

    
h_f = conj(hT_f);
hTh_f = hT_f.*h_f; 

C_f = (1 ./ (l1*hTh_f + l2*1 ));

A = @(x, l1, l2 , hTh_f , M) x - l1*(1-M).* real(ifft2( (hTh_f ./ (l1*hTh_f + l2*1 )) .* fft2((1-M).*x) )); % 2 fft's

Wu = W(u);

b = (1-M).*real(ifft2( h_f.*C_f.* ( l1*hT_f.*fft2(M.*y) + fft2(l2*Wu) )  ));  % 2 fft's


x = x_init;
x = (1-M).*x;  % projection
r =  b - A( x , l1, l2 , hTh_f,  M);   
r = (1-M).*r;  % projection
if exist('A2inv'), z = A2inv( r, l1, l2 , hTh_f ) ; else z = r; end
z = (1-M).*z;  % projection
p = z;
    
for it=1:N
    
    p = (1-M).*p;  % projection

    Ap = A( p , l1, l2, hTh_f,  M);
    alfa = sum(r(:).*z(:)) / sum( p(:).*Ap(:) );
    
    x_old = x;
    x = x + alfa*p;
    
    if it == N, continue, end
     
    r_old = r;   
    z_old = z;
    p_old= p;
    
    r = r - alfa*Ap;
    r = (1-M).*r;  % projection
    
    if exist('A2inv'), z = A2inv( r , l1, l2 , hTh_f ) ; else z = r; end
    z = (1-M).*z;  % projection
    
    beta = sum(z(:).*r(:)) / sum(z_old(:).*r_old(:));
    
    p  = z + beta*p;
    
end
w = x;

