%
% function [h] = ht2h(ht, sz1 ,sz2)
%
% Receives a filter "ht" centered at the center of the matrix "ht", and 
% returns a filter "h" equivalent to the filter "ht",
% but of size "sz1"x"sz2" and centered at the spectral origin: pixel (1,1) 
%
% Mariana S. C. Almeida; 2013.
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@gmail.com
%

function [h] = ht2h(ht, sz1 ,sz2)
 
h = zeros(sz1,sz2);
 
auxi = zeros(size(h)); auxi(1,1)=1; auxi = fftshift(auxi);
[c1 c2] = find(auxi==1);
 
fx = round((size(ht,1)-1)/2);
fy = round((size(ht,2)-1)/2);
 
h( (c1-fx):(c1+fx) , (c2-fy):(c2+fy) ) = ht;
h = ifftshift(h);
