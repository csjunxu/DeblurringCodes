%
% function x = fill_image(x,mask)
%
% Function that fills the unknown pixels of "x" (the ones maked with zero in mask matrix).
% The unknown pixels are replaced by averaged value of the surrounding known pixels.
%
% Mariana S. C. Almeida; 2013
% Instituto de Telecomunica��es, Lisbon, Portugal 
% marianascalmeida@.gmail.com
%
 
function x = fill_image(x,mask)
 
while numel(find(mask==0))
    divisor = conv2(double(mask), ones(3)/9, 'same' );
    x_fill = conv2(x.*mask, ones(3)/9, 'same' )./ ( divisor + (divisor==0) ) ;
    x = x.*mask + (1-mask).*x_fill;
    mask = 0.000001 < conv2(double(mask), ones(3), 'same' );
    
end


